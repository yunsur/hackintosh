#!/bin/sh

sudo rm -f /Library/Extensions/AppleHDAALC282.kext/Contents/MacOS/AppleHDA
sudo ln -s /System/Library/Extensions/AppleHDA.kext/Contents/MacOS/AppleHDA /Library/Extensions/AppleHDAALC282.kext/Contents/MacOS/AppleHDA
sudo touch /Library/Extensions

echo “Done.”
exit